#!/usr/bin/env python

from config import *
import csv
from elevenlabs import set_api_key, voices, generate, save

game = game_dict[game_name]
voice_dict = game["voices"]


savepath = game["savepath"] + "/"
if lang != game["main_lang"]:
    savepath += "tl/" + lang + "/" # Descend into corresponding tl dir if voice not main lang
savepath += "audio/voice/"

model = "eleven_"
model += "multilingual" #if lang == "English" else "multilingual"
model += "_v2"

set_api_key(api_key)

print("Game: " + game_name)
print("Language: " + lang)
print("Interpreted file: " + filename)
print("Example path: " + savepath + "[voice_id].mp3")
print("Example voice: \"" + game_name + ": " + "[character name]\"")
print("================================")
print("Model: " + model)
print("API key: " + api_key)
print("\n")
print("Make sure the the dialogue.csv is in the voiceover-folder!")
inchar = input("Are all the details correct? (y/n) ")
if inchar != "y":
    exit(1)

print("Caching voices...")
# voices()

file = open(filename, encoding='utf-8')
reader = csv.DictReader(file, delimiter=delimiter) # Interprets the CSV file as a dictionary
try:
    for row in reader:
        voice_dict[row["Character"]] == 0
        break
except KeyError as error:
    print(error)
    print("\n\n================================================================")
    print("Did you choose a right delimiter for the " + filename + " file?")
    delimiter = delimiter.replace("\t", "\\t")
    print("The current one is: " + delimiter)
    print("You can find it at the bottom of 'config.py'")
    print("================================================================\n\n")
for row in reader:
    if voice_dict[row["Character"]] == 0:
         continue
    voice = game_name + ": " + voice_dict[row["Character"]] # Expects all voices to be their names
    audio = generate(
        text=row["Dialogue"],
        voice=voice,
        model=model
    )
    path = savepath + row["Identifier"] + ".mp3"
    print(path + ", " + voice + ", " + row["Dialogue"])
    save(audio, path);
