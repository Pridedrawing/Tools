game_name = "BEngel" # Corresponds to game name in 'game_dict' and ElevenLabs: "Bound To College", "BEngel", or "GOS"
lang = "portuguese" # Corresponds to 'game/tl/[lang]/' or "German" (BEngel) / English (BtC)

################################################################################

# Defines the voices' dictionary
# Mind the trailing commas!
bengel_voices = {
    "a": "Alien",
    "b": "Ben",
    "c": "Chris",
    "d": "Ben", 	# As the demonised version of himself
    "dog": "Demon",
    "e": "Elijah2",
    "h": "Hartmann",
    "hm": "Hartmann",
    "horse": "Marvin",
    "j": "Jeff",
    "k": "Kyle",
    "l": "Lucifer",
    "m": "Marvin",
    "md": "Marvin",
    "n": "Noah",
    "s": "Sabrina",
    "t": "Tim",
    "z": 0, 		# Ignored
    "": "Narrator",
    "centered": "Narrator",

    "e_nvl": "Sabrina", # Sabrina on the phone
    "n_nvl": "Jeff", 	# Jeff on the phone
    "t_nvl": "Tim"      # Tim on the phone
}

btc_voices = {
    "": "Narrator",
    "a": "Administrator",
    "A": "Administrator",
    "c": "Connor",
    "C": "Connor",
    "d": "Daniel",
    "D": "Daniel",
    "h": "Headmaster",
    "H": "Headmaster",
    "j": "Julian",
    "J": "Julian",
    "dog": "Julian",
    "jc": "Julio",
    "JC": "Julio",
    "jk": "Jupiter",
    "JK": "Jupiter",
    "ma": "Max",
    "MA": "Max",
    "m": "Mistress",
    "M": "Mistress",
    "n": "Ned",
    "N": "Ned",
    "na": "Nathan",
    "NA": "Nathan",
    "r": "Ron",
    "R": "Ron",
    "t": "Tom",
    "T": "Tom",
    "v": "Vincent",
    "V": "Vincent",
    "z": "Zen",
    "Z": "Zen",
    "man": "Man",
    "woman": "Woman",
    "bus": "Bus"

}

gos_voices = {
    "": "Narrator",
    "Liam": "Liam",
    "Cynthia": "Cynthia",
    "Cynthius": "Cynthia",
    "Trevor": "Trevor",
    "Oscar": "Oscar",
    "Brian": "Brian",
    "Ethan": "Ethan",
    "Marcus": "Marcus",
    "Calvin": "Calvin",
    "Henry": "Lumbard",
    "Nathan": "Nathan",
    "Marcus": "Marcus",
    "Customer": "Customer",
    "Receptionist": "Receptionist"
}

################################################################################

# Defines the games' dictionary
# The program expects the games' names to correlate
# with ElevenLabs voice entries:
# BEngel -> "BEngel: Chris"

game_dict = {
    "Bound To College": {
        "main_lang": "English",
        "voices": btc_voices,
        "savepath": "D:/Windows-Dateienordner/Dokumente/DAZ 3D/Novel/Test/BoundToCollege/game"
    },
    "BEngel": {
        "main_lang": "German",
        "voices": bengel_voices,
        "savepath": "D:/Windows-Dateienordner/Dokumente/DAZ 3D/Novel/Test/B_Engel/game"
    },

    "GOS": {
        "main_lang": "English",
        "voices": gos_voices,
        "savepath": "D:/Windows-Dateienordner/Dokumente/DAZ 3D/Novel/Test/Gay-Office-Sim/game"
    }
}

################################################################################

filename = "dialogue_missing.csv"
delimiter = ','  # ',' or '\t' for tab

api_key = "dcb7f099546b29f1a204415c8c3fe402"
