#!/usr/bin/env python

import csv
from config import *
import deepl

game = game_dict[game_name]

gamepath = game["path"] + "/"

tl = deepl.Translator(api_key)

print("Game: " + game_name)
print("Game path: " + gamepath)
print("Source language: " + game["main_lang"])
print("Target language: " + lang)
print("Target Directory: "+ lang_dir)
print()
print("Dialogue file: " + filename)
print("API key: " + api_key)
print("\n")
if input("Are all the details correct? (y/n) ") != "y":
    exit(1)

file = open(filename, encoding='utf-8')
reader = csv.DictReader(file, delimiter=delimiter) # Interprets the CSV file as a dictionary

tl_filename = ""
first = 1
for row in reader:
    # DeepL doesn't accept empty requests, translating [RelVal] is redundant
    if row["Dialogue"] in no_tl:
        continue

    if tl_filename != row["Filename"]:
        tl_filename = row["Filename"]
        # Facilitates not-closing unopened files on first pass
        ################################
        if first != 1:
            tl_file.write("\n# AUTO TRANSLATION END\n")
            for i in range(0, 81):
                tl_file.write("#")
            tl_file.write("\n")
            print("Closing " + gamepath + tl_filename)
            tl_file.close()
        else:
            first = 0

        print ("Opening " + gamepath + tl_filename)
        tl_file = open(gamepath + tl_filename, "a", encoding='utf-8')
        tl_file.write("\n")
        for i in range(0, 81):
            tl_file.write("#")
        tl_file.write("\n# AUTO TRANSLATION BEGIN\n\n")
        ################################

    text = tl.translate_text(
        text=row["Dialogue"],
        source_lang = game["main_lang"],
        target_lang = lang,
        glossary=glossaries[game["main_lang"]].setdefault(lang, None) if disable_gloss != 0 else None,
        #formality="more" if row["Character"] in game["formality"] else "less" # Set 'less' to default formality value
    ).text

    # Python ignores the quotation marks in "[what]"
    if row["Ren'Py Script"] == "[what]":
        row["Ren'Py Script"] = "\"[what]\""
    tl_text = row["Ren'Py Script"].replace("[what]", text)

    print(gamepath + tl_filename + ", " + row["Ren'Py Script"].replace("[what]", row["Dialogue"])+ " -> " + tl_text)
    # input("Okay?")

    # translate german [id]:
    #     c "[what]" with vpunch
    tl_file.write("translate " + lang_dir + " " + row["Identifier"] + ":\n")
    tl_file.write("    " + tl_text)
    tl_file.write("\n\n")
