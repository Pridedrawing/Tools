# The only languages that support the both the functionality of glossaries and tone adjustments are:
# German, Spanish, Polish, French, Italian, Dutch

lang_dir = "English"		# Corresponds to 'game/tl/[lang_dir]'
game_name = "BEngel"	# Corresponds to the 'game_dict' entry titles: "Bound To College" / "BEngel"
lang = "en-us"			# Corresponds to the ISO_639-1 language representation
                    # https://de.wikipedia.org/wiki/Liste_der_ISO-639-1-Codes
                    # pt-pt, de, ru, nl, fr, es, en-us
disable_gloss = 1		# Disables glossary support if not set to 0

# Defines an array of strings to not put through DeepL
no_tl = { "", "\"", "[RelVal]", "[name]", "[age]", "[Subject]","[LoveAdmin]", "[PlayerMark]", "[LoveJulian]", "[LoveJulio]", "[LoveRon]", "[LoveNed]", "[LoveVincent]", "[LoveMax]", "[LoveNathan]", "[LoveJupiter]", "[LoveJulio]", "[MarkVal]", "[PlayerMark]", "[new_version]", "{b}", "{/b}", "{i}", "{/i}", "{u}", "{/u}", "Pride TV", "PrideTV" }

################################################################################
# Lists of characters acting in a formal fashion
# The quality of the results may vary depending on the ambigousness of the language in relation to the games' main one

btc_formality = { "h", "m" }

bengel_formality = { }

################################################################################

# Defines the games' dictionary
# Path should point to where Ren'Py generates 'dialogue.csv'

game_dict = {
    "Bound To College": {
        "main_lang": "en",
        "path": "D:/Windows-Dateienordner/Dokumente/DAZ 3D/Novel/Test/BoundToCollege",
        "formality": btc_formality
    },
    "BEngel": {
        "main_lang": "de",
        "path": "D:/Windows-Dateienordner/Dokumente/DAZ 3D/Novel/Test/B_Engel",
        "formality": bengel_formality
    }
}

################################################################################

filename = "dialogue.csv"
delimiter = ","
api_key = "bcf9bc45-3353-4e6a-7394-8923c47ce64e"

with open("glossaries.json", 'r', encoding="utf-8") as file:
    import json
    glossaries = json.loads(file.read())
